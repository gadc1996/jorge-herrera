function redirection(){
    window.location.href = "http://www.jorge-herrera.com.mx/index.html";
}
setTimeout(redirection,3000);